const urlParams = new URLSearchParams(window.location.search);
const title = urlParams.get('title');
const description = urlParams.get('description');
const imageUrl = urlParams.get('imageUrl');
const price = urlParams.get('price'); 

document.getElementById('title').textContent = title;
document.getElementById('description').textContent = description;
document.getElementById('image').src = imageUrl;
document.getElementById('price').textContent = `Price: ₹ ${price}`; 

function getCart() {
  return JSON.parse(localStorage.getItem('cart')) || [];
}

function updateCartCount() {
  const cart = getCart();
  const cartCountElement = document.getElementById('cartCount');
  if (cartCountElement) {
    cartCountElement.textContent = cart.length; 
  }
}

updateCartCount(); 

document.getElementById('add-to-cart').addEventListener('click', () => {
  const cartItem = {
    title,
    description,
    imageUrl,
    price: parseFloat(price) 
  };

  let cart = getCart();
  cart.push(cartItem);
  localStorage.setItem('cart', JSON.stringify(cart));

  updateCartCount();

  alert('Item added to cart!');
});
